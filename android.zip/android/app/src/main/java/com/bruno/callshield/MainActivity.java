package com.bruno.callshield;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
